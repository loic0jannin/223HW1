# rolls model to copute the spread

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from tqdm import tqdm
import functions
import warnings

import math


def plot_rollsModel2(start=2, end=1001):
    # Initialize a list to store the proportions
    proportion_imaginary = []
    df_SPX_Index = pd.read_csv('data/SPX-Index.csv')
    d = np.diff(df_SPX_Index['close'])
    d = pd.Series(d, index=df_SPX_Index.index[1:])

    # Loop over different window sizes from start to end
    for rolling_cov_window in tqdm(range(start, end)):
        # Compute rolling covariance
        covariance_values = [np.cov(d[i-rolling_cov_window:i-1], d[i-rolling_cov_window+1:i], ddof=0)[0, 1] for i in range(rolling_cov_window, len(d))]

        # Calculate proportion of positive covariances
        proportion_positive = (np.array(covariance_values) > 0).sum() / len(covariance_values)

        # Append to the list
        proportion_imaginary.append(proportion_positive)

    # Plot the proportion of positive numbers
    plt.figure(figsize=(10, 6))
    plt.plot(range(start, end), proportion_imaginary, linestyle='-')
    plt.title('Proportion of Positive Numbers in Rolling Covariance')
    plt.xlabel('Window Size')
    plt.ylabel('Proportion of Positive Numbers')
    plt.grid(True)
    plt.tight_layout()
    plt.show()

def percentage_rolls(data):
    # returns the perdcentage of days when the rolls model is not defined
    return data['rolls_model'].isna().mean().round(4)*100

def plot_rollsModel(data):
    # plots the percentage of days when the rolls model is not defined for diff values of N
    N = np.arange(10, 1000)
    percentage = []

    # computes the rolls model once for the maximum value of N
    data = rolls_model(data, N.max())

    for n in tqdm(N):
        # adds the rolls model to the data
        data = rolls_model(data, n)

        # computes the percentage of days when the rolls model is not defined for the current value of N
        percentage.append(percentage_rolls(data))

    plt.plot(N, percentage)
    plt.xlabel('N')
    plt.ylabel('Percentage of days when the rolls model is not defined')
    plt.title('Percentage of days when the rolls model is not defined for diff values of N')

    plt.show()

plot_rollsModel2()